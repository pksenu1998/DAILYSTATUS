#Ebay  Web Scrapper::
#fetch in the current data of  teh wrist watch from ebay
# and write them in csv file
#Before starting scrapping first go manually see what to scrap with the help of inspect
#In this we will collect Title, price, quantity of sold item


#
#1.Make a request to the ebay.com & get a page
#2.Collect data from each detail page
#3.Collect all links to detail pages of each product
#4.Write scrapped data to a csv file

import requests
from bs4 import BeautifulSoup
import csv

#this function take url 
def get_page(url):
    response =requests.get(url)
    #print(response.ok) #this tells that ebay server respose successfully if return true 
    #print(response.status_code)#if this return 200 then it means server respond succefully
    if not response.ok:
        print('server responded:', response.status_code)
    else: #if the server responded properly then we will get html code-> 
         soup=BeautifulSoup(response.text,'lxml') #html code of a page
    return soup 

def get_detail_data(soup):
    #title
    #price
    #item sold
    try:
        title = soup.find('h1',class_="it-ttl").text.replace('Details about', ' ').replace('\xa0',' ').strip() #for replacing 
    except:
        title=''
    

    try:
        p=soup.find('span',class_ = 'notranslate').text.strip()#EVERY THING RETURN IS OBJECT U CAN PERFORM ANY FUNCTION IN THIS
        curency,price=p.split(' ')
       
    except:
        curency=' '
        price= ' '



    try:
        sold=soup.find('a', class_ = 'vi-txt-underline').text.strip().split(' ')[0]
        
    except:
        sold=' '


    data = {
        'title':title,
        'price': price,
        'currency':curency,
        'total sold':sold
    }
   # print(data)
    return data

def get_index_data(soup): #for getting all links  
    try:
        links = soup.find_all('a',class_='s-item__link')
    except:
        links = []
    urls = [ item.get('href') for item in links]
    
    return urls
    #print(links)


        
def write_csv(data,url):
     with open('E:/DataScience/output.csv','a') as csvfile:
         writer = csv.writer(csvfile)
         row= [data['title'], data['price'],data['currency'],data['total sold'],url] 
         writer.writerow(row)

def main():
    url='https://www.ebay.com/sch/i.html?_nkw=mens+watchs&_pgn=1'
    #get_detail_data(get_page(url))
    products = get_index_data(get_page(url))
    #get_detail_data(get_page('https://www.ebay.com/sch/i.html?_nkw=mens+watchs&_pgn=1'))
    for link in products:  
        data = get_detail_data(get_page(link))
        write_csv(data,link)
        print(data)


if __name__ == '__main__': #if the program is run from console the name attribute will be main or if imported to other project its name attribut will be ebay_scraping(file name)
    main() #if the the name attribute is true then the main function will be called

